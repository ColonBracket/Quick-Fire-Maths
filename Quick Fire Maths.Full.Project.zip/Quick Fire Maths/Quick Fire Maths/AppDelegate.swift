//
//  AppDelegate.swift
//  Quick Fire Maths
//
//  Created by Andrew Smailes on 18/05/2016.
//  Copyright © 2016 Delta Developers Team. All rights reserved.
//

import Cocoa

@NSApplicationMain
class AppDelegate: NSObject, NSApplicationDelegate {



    func applicationDidFinishLaunching(aNotification: NSNotification) {
        // Insert code here to initialize your application
    }

    func applicationWillTerminate(aNotification: NSNotification) {
        // Insert code here to tear down your application
    }


}

