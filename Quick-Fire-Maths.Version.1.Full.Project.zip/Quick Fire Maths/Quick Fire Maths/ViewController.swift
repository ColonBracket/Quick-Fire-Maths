//
//  ViewController.swift
//  Quick Fire Maths
//
//  Created by Andrew Smailes on 18/05/2016.
//  Copyright © 2016 Delta Developers Team. All rights reserved.
//

import Cocoa

extension Double {
    /// Rounds the double to decimal places value
    func roundToPlaces(places:Int) -> Double {
        let divisor = pow(10.0, Double(places))
        return round(self * divisor) / divisor
    }
}

class ViewController: NSViewController {

    override func viewWillAppear() {
        self.view.layer?.backgroundColor = NSColor.init(red: 0.14, green: 0.37, blue: 0.46, alpha: 1).CGColor
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.wantsLayer = true
        startAlert.messageText = "Welcome to Quick Fire Maths!"
        startAlert.informativeText = "Select your quiz type! You have 30 seconds to answer all questions."
        startAlert.addButtonWithTitle("Random")
        startAlert.addButtonWithTitle("Division")
        startAlert.addButtonWithTitle("Multiplication")
        startAlert.addButtonWithTitle("Subtraction")
        startAlert.addButtonWithTitle("Addition")
        
        let resolution = startAlert.runModal()
        
        if resolution == NSAlertFirstButtonReturn {
            operateRandomly = true
        }
        else if resolution == NSAlertSecondButtonReturn {
            operationMode = 4
        }
        else if resolution == NSAlertThirdButtonReturn {
            operationMode = 3
        }
        else if resolution == NSAlertThirdButtonReturn + 1 {
            operationMode = 2
        }
        else if resolution == NSAlertThirdButtonReturn + 2 {
            operationMode = 1
        }
        
        endAlert.messageText = "The quiz is over! Good game!"
        endAlert.icon = NSImage(named: "icon_nsalert_512x512@2x.png")
        
        mainTimer = NSTimer.scheduledTimerWithTimeInterval(1.0, target: self, selector: #selector(ViewController.secondPassed), userInfo: nil, repeats: true)
        
        runQuestion()
        
        // Do any additional setup after loading the view.
    }

    
var number1 = 0.0
var number2 = 0.0
var operationMode = 0
var operateRandomly = false
    
    // add string for percentage correct to be displayed

var doubleSuggestion2 = 0.0
var doubleSuggestion3 = 0.0
var doubleSuggestion4 = 0.0

var realAnswer = 0.0

var answersCorrect = 0.0
var questionsRun = 0.0
var secondsRemaining = 30

var mainTimer = NSTimer()

var startAlert = NSAlert()
var endAlert = NSAlert()
    
    // all relevent variables initialised - doubles used to allow division to be tested
    
func generateOperationMode() { // for random function, randomly generates operation mode to be used
    operationMode = Int(arc4random_uniform(4)) + 1
}

func generateRandomNumbers(realOperationMode: Int) { // actual question generator, accepting the operation mode as an input to work with
    
    number1 = Double(arc4random_uniform(15)) + 5
    number2 = Double(arc4random_uniform(5)) + 5
    
    if realOperationMode == 1 { // addition
        realAnswer = number1 + number2
        operationSymbol.stringValue = "+"
    }
    else if realOperationMode == 2 { // subtraction
        realAnswer = number1 - number2
        operationSymbol.stringValue = "-"
    }
    else if realOperationMode == 3 { // multiplication
        realAnswer = number1 * number2
        operationSymbol.stringValue = "*"
    }
    else if realOperationMode == 4 { // division
        realAnswer = number1 / number2
        realAnswer = realAnswer.roundToPlaces(2) // rounding real answer to 2 decimal places
        operationSymbol.stringValue = "/"
    }
    
    // generating random alternative answers
    
    doubleSuggestion2 = realAnswer + Double(arc4random_uniform(3)) - 10
    doubleSuggestion3 = realAnswer + Double(arc4random_uniform(25)) + 1
    doubleSuggestion4 = realAnswer + Double(arc4random_uniform(15)) + 1
    
}

func runQuestion() { // encompasses other functions - runs to present each new question to the user
    
    if operateRandomly == true {
        generateOperationMode()
    }
    
    generateRandomNumbers(operationMode)
    
    number1Display.stringValue = String(format: "%.0f", number1)
    number2Display.stringValue = String(format: "%.0f", number2)
    
    randomlyAssignSuggestions()
}

func secondPassed() { // specified as a selector to run every second
    
    guard secondsRemaining > 0 else {
        mainTimer.invalidate()
        questionsRun = 25
        answersCorrectDisplay.stringValue = String(Int(100 * (answersCorrect/questionsRun))) + "%"
        endAlert.informativeText = "You have run out of time... You got " + String(Int(100 * (answersCorrect/questionsRun))) + "%!"
        endAlert.runModal()
        NSApplication.sharedApplication().terminate(self)
        return
    }
    
    secondsRemaining -= 1
    
    secondsRemainingDisplay.integerValue = secondsRemaining
    
}

func randomlyAssignSuggestions() {
    
    let realPosition = Int(arc4random_uniform(4)) + 1
    
    switch realPosition {
        
    case 1: suggestion1.title = String(realAnswer)
    suggestion2.title = String(doubleSuggestion2)
    suggestion3.title = String(doubleSuggestion3)
    suggestion4.title = String(doubleSuggestion4)
    case 2: suggestion2.title = String(realAnswer)
    suggestion1.title = String(doubleSuggestion2)
    suggestion3.title = String(doubleSuggestion3)
    suggestion4.title = String(doubleSuggestion4)
    case 3: suggestion3.title = String(realAnswer)
    suggestion1.title = String(doubleSuggestion2)
    suggestion2.title = String(doubleSuggestion3)
    suggestion4.title = String(doubleSuggestion4)
    case 4: suggestion4.title = String(realAnswer)
    suggestion1.title = String(doubleSuggestion2)
    suggestion2.title = String(doubleSuggestion3)
    suggestion3.title = String(doubleSuggestion4)
        
    default: break
        
    }
    
}

@IBOutlet weak var number1Display: NSTextField!
@IBOutlet weak var number2Display: NSTextField!
@IBOutlet weak var secondsRemainingDisplay: NSTextField!
    @IBOutlet weak var questionsRemainingDisplay: NSTextField!
@IBOutlet weak var operationSymbol: NSTextField!

@IBOutlet weak var suggestion1: NSButton!
@IBOutlet weak var suggestion2: NSButton!
@IBOutlet weak var suggestion3: NSButton!
@IBOutlet weak var suggestion4: NSButton!

@IBOutlet weak var answersCorrectDisplay: NSTextField!
    
    func questionsFinished() {
        endAlert.informativeText = "Well done - you finished all the questions in time! You got " + String(Int(100 * (answersCorrect/questionsRun))) + "%"
        endAlert.runModal()
        NSApplication.sharedApplication().terminate(self)
    }

@IBAction func chooseSuggestion1(sender: NSButton) { // display questions run to the user
    
      questionsRun += 1
    
    guard questionsRun < 25 else {
        questionsFinished()
        return
    }
    
    if Double(suggestion1.title) == realAnswer {
        
        answersCorrect += 1
    }
    
    answersCorrectDisplay.stringValue = String(Int(100 * (answersCorrect/questionsRun))) + "%"
    
    runQuestion()
    
    questionsRemainingDisplay.doubleValue = 25-questionsRun
    
}

@IBAction func chooseSuggestion2(sender: NSButton) {
    
      questionsRun += 1
    
    guard questionsRun < 25 else {
        questionsFinished()
        return
    }
    
    if Double(suggestion2.title) == realAnswer {
        
        answersCorrect += 1
    }
    
    answersCorrectDisplay.stringValue = String(Int(100 * (answersCorrect/questionsRun))) + "%"
    
    runQuestion()
    
    questionsRemainingDisplay.doubleValue = 25-questionsRun
    
}
@IBAction func chooseSuggestion3(sender: NSButton) {
    
    questionsRun += 1
    
    guard questionsRun < 25 else {
        questionsFinished()
        return
    }
    
    if Double(suggestion3.title) == realAnswer {
        
        answersCorrect += 1
    }
    
    answersCorrectDisplay.stringValue = String(Int(100 * (answersCorrect/questionsRun))) + "%"
    
    runQuestion()
    
    questionsRemainingDisplay.doubleValue = 25-questionsRun
    
}
@IBAction func chooseSuggestion4(sender: NSButton) {
    
    questionsRun += 1
    
    guard questionsRun < 25 else {
        questionsFinished()
        return
    }
    
    if Double(suggestion4.title) == realAnswer {
        
        answersCorrect += 1
    }
    
    answersCorrectDisplay.stringValue = String(Int(100 * (answersCorrect/questionsRun))) + "%"
    
    runQuestion()
    
    questionsRemainingDisplay.doubleValue = 25-questionsRun
    
}

override var representedObject: AnyObject? {
didSet {
    // Update the view, if already loaded.
}
}

}